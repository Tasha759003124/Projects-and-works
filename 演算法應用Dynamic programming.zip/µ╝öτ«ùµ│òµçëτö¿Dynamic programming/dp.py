#王琳     508170040
#蘇靖媛   508170129

from functools import lru_cache

value = [50,10,80,40,60,30,20,40]
prev = [0,0,0,1,0,2,3,5]

@lru_cache(maxsize=128)
def opt(x):
    if x == 0:
        return 0
    else:
        return max(opt(x-1),value[x-1]+opt(prev[x-1]))  #遞歸關係式：max(不選，選)

#程式自動從1-8條綫中找到最大值並印出
i= 1
for i in range(9):
    maxs=opt(i)
    print('前%s條綫路中，最大報酬為%s'%(i,maxs))
    i=i+1
