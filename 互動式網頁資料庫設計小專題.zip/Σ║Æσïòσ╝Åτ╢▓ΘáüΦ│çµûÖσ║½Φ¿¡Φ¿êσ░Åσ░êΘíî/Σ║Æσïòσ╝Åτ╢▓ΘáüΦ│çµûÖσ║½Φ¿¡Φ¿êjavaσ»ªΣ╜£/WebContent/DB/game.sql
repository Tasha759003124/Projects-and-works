show databases;
create database game;
use game;
CREATE TABLE `products` (
  `productsid` int primary key,
  `productsname` varchar(255) NOT NULL,
  `nickname` varchar(255) NOT NULL,
  `release` varchar(255) NOT NULL,
  `price` int(4) NOT NULL,
  `specialoffer` int (4) NOT NULL
);
CREATE TABLE `ratingsystem` (
  `ratingsystemid` int primary key,
  `ratingsystemage` varchar(255) NOT NULL,
  `ratingsystemlimit` int(11) NOT NULL
) ;
CREATE TABLE `publisher` (
  `publisherid` int primary key,
  `publishernationality` varchar(255) NOT NULL,
  `publishercreationdate` varchar(255) NOT NULL
) ;

CREATE TABLE `comments` (
  `commentid` int primary key,
  `allcomment` varchar(255) NOT NULL,
  `recentcomment` varchar(255) NOT NULL,
  `praise` int(4) NOT NULL,
  `negative` int(4) NOT NULL
) ;

CREATE TABLE `lablename` (
  `lableid` int primary key,
  `players` int(4) NOT NULL,
  `labelname` varchar(255) NOT NULL
) ;


INSERT INTO `products` (`productsid`, `productsname`, `nickname`,`release`, `price`, `specialoffer`) VALUES
(1, 'MONSTER HUNTER: WORLD', '魔物獵人：世界', '2018/8/10', 1960, 998),
(2, 'PLAYERUNKNOWNS BATTLEGROUNDS', '吃雞', '2017/12/21', 799, 439),
(3, 'Grand Theft Auto V', 'GTA5', '2015/4/14', 1980, 500),
(4, 'The Witcher® 3: Wild Hunt', '巫師3', '2015/5/18', 868, 239),
(5, 'Assassins Creed® Odyssey', '刺客教條：奧德賽', '2018/10/6', 1620, 1200),
(6, '古劍奇譚3', '古劍3', '2018/12/14', 438, 230),
(7, 'DARK SOULS™ III', '黑暗靈魂3', '2016/4/12', 1290, 435),
(8, 'Age of Empires II HD', '世紀帝國II HD', '2013/4/10', 468, 274),
(9, 'Sherlock Holmes: The Devils Daughter', '夏洛克福爾摩斯：惡魔的女兒', '2016/6/10', 1038, 436),
(10, 'Resident Evil 6 / Biohazard 6', '惡靈古堡6', '2013/3/22', 786, 286);

INSERT INTO `ratingsystem`(`ratingsystemid` ,`ratingsystemage` ,`ratingsystemlimit`) VALUES
(1,'限制級',18),
(2,'限制級',18),
(3,'限制級',18),
(4,'限制級',18),
(5,'限制級',18),
(6,'全年齡',0),
(7,'保護級',12),
(8,'輔導級',16),
(9,'限制級',18),
(10,'限制級',18);

INSERT INTO `publisher`(`publisherid` ,`publishernationality` ,`publishercreationdate`)VALUES
(1,'日本','1979年5月'),
(2,'韓國','2007年3月 '),
(3,'美國','2005年12月'),
(4,'波蘭','1994年5月'),
(5,'法國','1986年3月'),
(6,'中國','2007年10月 '),
(7,'日本','1986年11月'),
(8,'美國','2002年1月'),
(9,'法國','1981年2月'),
(10,'日本','1979年5月');

INSERT INTO `comments`(`commentid` ,`allcomment` ,`recentcomment` ,`praise` ,`negative`)VALUES
(1,'一致好評','一致好評',70,30),
(2,'一致好評','一致好評',70,30),
(3,'一致好評','一致好評',70,30),
(4,'一致好評','一致好評',70,30),
(5,'一致好評','一致好評',70,30),
(6,'一致好評','一致好評',70,30),
(7,'一致好評','一致好評',70,30),
(8,'一致好評','一致好評',70,30),
(9,'一致好評','一致好評',70,30),
(10,'一致好評','一致好評',70,30);

INSERT INTO `lablename`(`lableid` ,`players` ,`labelname`)VALUES
(1,65,'冒險'),
(2,86,'冒險'),
(3,46,'冒險'),
(4,56,'冒險'),
(5,34,'冒險'),
(6,98,'冒險'),
(7,45,'冒險'),
(8,42,'冒險'),
(9,65,'冒險'),
(10,87,'冒險');

