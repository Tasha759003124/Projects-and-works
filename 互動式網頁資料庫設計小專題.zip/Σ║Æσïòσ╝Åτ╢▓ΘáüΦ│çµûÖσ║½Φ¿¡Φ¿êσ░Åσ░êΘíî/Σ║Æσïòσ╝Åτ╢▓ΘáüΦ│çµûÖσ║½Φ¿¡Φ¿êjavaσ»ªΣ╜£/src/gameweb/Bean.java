//508170129 蘇靖媛  508170076 黃亭舒
package gameweb;
import java.util.*;
public class Bean implements java.io.Serializable{
  private String gamename = null;
//接收需做處理的jsp資料
  public Bean() {

  }

  public String getGamename() {
    return gamename;
  }

  public void setGamename(String gamename) {
    this.gamename = gamename;
    System.out.println(gamename);
  }
  

}
