package oop3;

public class Gym {

	public Pokemon fight(Pokemon pok1, Pokemon pok2) {
		if(pok1.getCp()>pok2.getCp()) {
			pok1.setLevel(pok1.getLevel()+1);
			return pok1;
		}else {
			pok2.setLevel(pok2.getLevel()+1);
			return pok2;
		}
			
	} 
}
