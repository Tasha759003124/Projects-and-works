package oop3;

public class Pokemon {

		private int hp;
		
		private int cp;
		
		private String name;
		
		private int level;
		
		private int stardust;

		public void powerup() {
			stardust = stardust - 10;
			hp+=5;
		}
		public void evolve() {
			stardust = stardust - 50;
			cp=cp+50;
		}
		
		
		public int getHp() {
			return hp;
		}

		public void setHp(int hp) {
			this.hp = hp;
		}

		public int getCp() {
			return cp;
		}

		public void setCp(int cp) {
			this.cp = cp;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public int getLevel() {
			return level;
		}

		public void setLevel(int level) {
			this.level = level;
		}

		public int getStardust() {
			return stardust;
		}

		public void setStardust(int stardust) {
			this.stardust = stardust;
		}
		
		
}
