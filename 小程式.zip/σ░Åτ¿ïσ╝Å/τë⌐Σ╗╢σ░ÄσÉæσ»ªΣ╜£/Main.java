package oop3;

public class Main {

	public static void main(String[] args) {
		
		Pokemon pikachu = new Pokemon();
		pikachu.setName("Pikachu"); 
		pikachu.setLevel(1);
		pikachu.setCp(50);
		
		Pokemon phyduck = new Pokemon();
		phyduck.setName("Phyduck"); 
		phyduck.setLevel(1);
		phyduck.setCp(25);
		
		Gym gym = new Gym();
		Pokemon winner = gym.fight(pikachu,phyduck);
		System.out.println(winner.getName()+" ; "+winner.getLevel());
		
		

	}

}
