//Switch 練習
package oop;
import java.util.*;
public class Main {

	public static void main(String[] args) {

		Scanner main= new Scanner(System.in);
		int score = main.nextInt();
		   
			int level = score/10;
			System.out.println(level);
			
			switch(level) {
			case 10:
			
				if(score != 100 ) {
					System.out.println("invalid");
					}
				else {
				System.out.println("A");
				break;
				}
			case 9:
				System.out.println("A");
				break;
			case 8:
				System.out.println("B");
				break;
			case 7:
				System.out.println("C");
				break;
			case 6:
				System.out.println("D");
				break;
			case 5:
			case 4:
		    case 3:
			case 2:
			case 1:	
			case 0:
				if(score >= 0) {
				System.out.println("E");
				break;
				}
			default:
				System.out.println("invalid");
				break;
			}
			
			main.close();
	}

}
