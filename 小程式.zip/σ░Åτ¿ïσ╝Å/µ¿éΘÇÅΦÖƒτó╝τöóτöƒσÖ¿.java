
public class Poo {

	public static void main(String[] args) {
		

	



	int [] lottery = new int[6];
			
			
				int count = 0;
				while(count<lottery.length) {
					int number = (int)Math.ceil(Math.random()* 36)+1;
					System.out.println(number);
					
					boolean isExist = false;
					
					for(int i = 0;i<count;i++) {
					if(lottery[i] == number) {
						isExist = true;
						System.out.println("exist");
						break;
						}
					}
					if(!isExist) {
						lottery[count] = number;
						count++;
					}
					
					
						}
					}
				
				
				
				
			
				
				
				
				
			}