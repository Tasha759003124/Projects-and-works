package main;

public class TPEWeather {
	
	public static boolean isItSunny() {
		return true;
	}
	public static boolean isNotCrowded() {
		return false;
	}
}
