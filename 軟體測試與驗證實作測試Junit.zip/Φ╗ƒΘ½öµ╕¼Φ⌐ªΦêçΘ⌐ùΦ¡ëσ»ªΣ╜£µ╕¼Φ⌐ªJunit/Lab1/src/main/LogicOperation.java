package main;

public class LogicOperation {

	public static int operator(int x, boolean cond1, boolean cond2, boolean cond3) {
		if (cond1) {
			x++;
		}
		if (cond2) {
			x--;
		}
		if (cond3) {
			x *= 1;
		}
		return x;
	}

	public static int moreOpertor(int x, boolean cond1, boolean cond2, boolean cond3) {

		if (cond1 && cond2 && cond3) {
			x = (int) Math.pow(x, 2);
		} else {
			x *= 2;
		}
		return x;
	}

}
