package test;

import static org.junit.Assert.*;

import org.junit.Test;

import main.LogicOperation;

public class LogicOperationTest {

	private static LogicOperation logicoperation;
	
	

	   @SuppressWarnings("static-access")
	   @Test
	   public void testIdentity() {
		assertEquals(2, logicoperation.operator(2, true, true, true));
		System.out.println("When input the value 2, then output the result : 2 in the testIdentity.");
	   }
		
		
	    @SuppressWarnings("static-access")
		@Test
	    public void testAllTrue() {
	        assertEquals(5, logicoperation.operator(5, true, true, true));
	        System.out.println("When input the value 5, then output the result : 5 in the testAllTrue.");
	    }
	    
	    
	    @SuppressWarnings("static-access")
		@Test
	    public void testAllFalse() {
	        assertEquals(2, logicoperation.operator(2, false, false, false));
	        System.out.println("When input the value 2, then output the result : 2 in the testAllFalse.");
	    }

	   
	    @SuppressWarnings("static-access")
	    @Test 
	    public void testTrueTrueFalse() {
	        assertEquals(1, logicoperation.operator(1, true, true, false));
	        System.out.println("When input the value 1, then output the result : 1 in the testTrueTrueFalse.");
	    }
	    
	    @SuppressWarnings("static-access")
	    @Test 
	    public void testTrueFalseTrue() {
	    	assertEquals(1, logicoperation.operator(0, true, false, true));
	    	System.out.println("When input the value 0, then output the result : 1 in the testTrueFalseTrue.");
	    }
	    
	    @SuppressWarnings("static-access")
	    @Test 
	    public void testTrueFalseFalse() {
	    	assertEquals(2, logicoperation.operator(1, true, false, false));
	    	System.out.println("When input the value 1, then output the result : 2 in the testTrueFalseFalse.");
	    }
	    
	    @SuppressWarnings("static-access")
	    @Test 
	    public void testFalseTrueTrue() {
	    	assertEquals(1, logicoperation.operator(2, false, true, true));
	    	System.out.println("When input the value 2, then output the result : 1 in the testFalseTrueTrue.");
	    }
	    
	    @SuppressWarnings("static-access")
	    @Test 
	    public void testFalseTrueFalse() {
	    	assertEquals(-1, logicoperation.operator(0, false, true, false));
	    	System.out.println("When input the value 0, then output the result : -1 in the testFalseTrueFalse.");
	    }
	    
	    @SuppressWarnings("static-access")
	    @Test 
	    public void testFalseFalseTrue() {
	    	assertEquals(1, logicoperation.operator(1, false, false, true));
	    	System.out.println("When input the value 1, then output the result : 1 in the testFalseFalseTrue.");
	    }

	    @SuppressWarnings("static-access")
		@Test
	    public void testMoreOperator() {
	    	assertEquals(4, logicoperation.moreOpertor(2, true, true, true));
	    	System.out.println("When input the value 2, then output the result : 4 in the testMoreOperator.");
	    }
	    
	    @SuppressWarnings("static-access")
		@Test
	    public void testMoreOperatorElse() {
	    	assertEquals(6, logicoperation.moreOpertor(3, false, false, false));
	    	System.out.println("When input the value 3, then output the result : 6 in the testMoreOperatorElse.");
	    }

}
