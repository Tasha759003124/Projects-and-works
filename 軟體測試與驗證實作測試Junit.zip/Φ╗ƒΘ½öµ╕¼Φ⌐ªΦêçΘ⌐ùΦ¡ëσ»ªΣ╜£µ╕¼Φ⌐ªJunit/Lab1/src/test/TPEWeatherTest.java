package test;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;

import main.TPEWeather;

public class TPEWeatherTest {

	private static TPEWeather tpeweather;

	@BeforeClass
	public static void initTPEWeather() {

		tpeweather = new TPEWeather();

	}

	@Test
	public void testIsItSunny() {

		boolean x = tpeweather.isItSunny();
		assertTrue(x);
		System.out.println("Today's taipei weather is sunny. "+ x);

	}

	@Test
	public void testIsNotCrowded() {

		boolean x = tpeweather.isNotCrowded();
		assertFalse(x);
		System.out.println("Today's taipei weather is not crowded. "+ x);

	}

}
