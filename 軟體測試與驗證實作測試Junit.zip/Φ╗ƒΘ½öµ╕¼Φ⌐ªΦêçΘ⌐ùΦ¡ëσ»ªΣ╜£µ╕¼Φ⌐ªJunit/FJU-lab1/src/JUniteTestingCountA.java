import static org.junit.Assert.*;

import org.junit.Test;

public class JUniteTestingCountA {

	@Test
	public void test() {
		JUniteTesting h = new JUniteTesting();
		int input =  h.countA("Java");
		assertEquals(2,input);
	}

}
