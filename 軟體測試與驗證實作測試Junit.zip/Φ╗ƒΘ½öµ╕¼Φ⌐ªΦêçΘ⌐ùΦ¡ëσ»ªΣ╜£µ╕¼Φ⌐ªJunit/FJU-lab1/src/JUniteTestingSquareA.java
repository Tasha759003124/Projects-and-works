import static org.junit.Assert.*;

import org.junit.Test;

public class JUniteTestingSquareA {

	@Test
	public void test() {
		JUniteTesting t = new JUniteTesting();
		int output = t.squareA(5);
		assertEquals(25,output);
	}
	

}
