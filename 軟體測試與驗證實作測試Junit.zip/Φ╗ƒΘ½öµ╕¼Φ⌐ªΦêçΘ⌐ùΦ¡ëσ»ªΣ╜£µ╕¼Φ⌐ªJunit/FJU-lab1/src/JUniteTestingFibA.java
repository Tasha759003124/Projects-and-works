import static org.junit.Assert.*;

import org.junit.Test;

public class JUniteTestingFibA {

	@Test
	public void test() {
		JUniteTesting c = new JUniteTesting();
		int output = c.fibA(5);
		assertEquals(120,output);
	}

}
