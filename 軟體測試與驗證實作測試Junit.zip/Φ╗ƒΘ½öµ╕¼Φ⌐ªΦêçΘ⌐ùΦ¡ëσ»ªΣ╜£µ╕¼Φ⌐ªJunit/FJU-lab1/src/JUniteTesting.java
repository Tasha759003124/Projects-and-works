
public class JUniteTesting {
	
	public int squareA(int x) {
		return x*x;
	}
	public int countA(String word) {
		int count = 0;
		for(int i = 0; i<word.length();i++) {
			if(word.charAt(i) == 'a' || word.charAt(i) == 'A') {
			  
				count++;
		}
		
	}
	return count;
		
	}
	public int fibA(int f) {
		
		 if(f==1)
				return 1;
		
			else
				return f*fibA(f-1); 
		 }
	}


