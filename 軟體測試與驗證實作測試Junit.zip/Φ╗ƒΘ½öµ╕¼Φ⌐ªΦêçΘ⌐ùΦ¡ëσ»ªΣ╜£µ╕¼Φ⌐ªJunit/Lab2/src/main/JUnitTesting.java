package main;

public class JUnitTesting {
	public int printNumber() {
		return 9;
	}
	public int addTwoNumber(int x,int y) {
		return x+y;
	}
	public int subtractTwoNumbers(int x,int y) {
		return x-y;
	}

}
