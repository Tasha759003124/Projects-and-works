/**
 * 
 */
package test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import main.JUnitTesting;

public class JUnitTestingTest {

	private static JUnitTesting junitesting;
	@BeforeClass
	public static void  initJUnitTesting(){
		junitesting = new JUnitTesting();
	}
	
	@Before
	public void beforeEachTest() {
		System.out.println("before");
	}
	
	
	@After
	public void afterEachTest() {
		System.out.println("after");
	}

	@Test
	public void displayHiddenNumber() {
		int x = junitesting.printNumber();
		assertEquals(9,x);
		System.out.println("printNumber");
	}

	@Test
	public void addTwoNumbersTest() {
		int x = junitesting.addTwoNumber(2,2);
		assertEquals(4,x);
		System.out.println("addTwoNumber");
	}

	@Test
	public void subtractTwoNumbersTest() {
		int x = junitesting.subtractTwoNumbers(2,1);
		assertEquals(1,x);
		System.out.println("subtractTwoNumbers");
	}

}
