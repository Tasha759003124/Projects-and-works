#508170129 蘇靖媛
#508170076 蔡名彥

#import 模組
import sys
import pygame
from ..sprites import Catt


#遊戲開始介面
def GameStartInterface(screen, sounds, cfg):

    hintword= pygame.font.Font('freesansbold.ttf',32)  #初始遊戲提示板設定
    hint = hintword.render('Press Space or Up to Start the Game !!',True,cfg.BLACK)
    hintrect = hint.get_rect()
    hintrect.center = (300,150)
    cat = Catt(cfg.IMAGE_PATHS['cat']) #遊戲開始貓的圖片路徑導入
    ground = pygame.image.load(cfg.IMAGE_PATHS['ground']).subsurface((0, 0), (0, 0)) #壁紙的設定、圖片導入
    rect = ground.get_rect()
    rect.left, rect.bottom = cfg.SCREENSIZE[0]/20, cfg.SCREENSIZE[1]
    clock = pygame.time.Clock()
    press_flag = False

    #遊戲期使觸發判定
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE or event.key == pygame.K_UP:
                    press_flag = True
                    cat.jump(sounds)
        cat.update()
        screen.fill(cfg.BACKGROUND_COLOR) #畫出壁紙並顯示於螢幕
        screen.blit(ground, rect)
        cat.draw(screen) #畫出貓並顯示於螢幕
        screen.blit(hint,hintrect) #畫出提示板並顯示於螢幕
        pygame.display.update()
        clock.tick(cfg.FPS)
        
        #按鍵出發會使貓的跳躍動作被執行
        if (not cat.is_jumping) and press_flag:
            return True


   