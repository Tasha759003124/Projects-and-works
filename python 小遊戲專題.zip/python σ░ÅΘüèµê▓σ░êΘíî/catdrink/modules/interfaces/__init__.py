#508170129 蘇靖媛
#508170076 蔡名彥

#初始化
from .gameend import GameEndInterface
from .gamestart import GameStartInterface