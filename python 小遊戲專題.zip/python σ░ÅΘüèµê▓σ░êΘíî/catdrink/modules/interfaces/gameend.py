#508170129 蘇靖媛
#508170076 蔡名彥

#import 模組
import sys
import pygame


#遊戲結束介面
def GameEndInterface(screen, cfg):
    replay_image = pygame.image.load(cfg.IMAGE_PATHS['replay']) #重新開始設定
    replay_image = pygame.transform.scale(replay_image, (35, 31))
    replay_image_rect = replay_image.get_rect()
    replay_image_rect.centerx = cfg.SCREENSIZE[0] / 2
    replay_image_rect.top = cfg.SCREENSIZE[1] * 0.52
    gameover_image = pygame.image.load(cfg.IMAGE_PATHS['gameover']) #遊戲結束設定
    gameover_image = pygame.transform.scale(gameover_image, (190, 11))
    gameover_image_rect = gameover_image.get_rect()
    gameover_image_rect.centerx = cfg.SCREENSIZE[0] / 2
    gameover_image_rect.centery = cfg.SCREENSIZE[1] * 0.35
    clock = pygame.time.Clock()

    #遊戲在觸發遊戲的基本判定
    while True:
        for event in pygame.event.get(): #離開
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN: #開始
                if event.key == pygame.K_SPACE or event.key == pygame.K_UP:
                    return True
            elif event.type == pygame.MOUSEBUTTONDOWN: #重新開始
                mouse_pos = pygame.mouse.get_pos()
                if replay_image_rect.collidepoint(mouse_pos):
                    return True
            
        screen.blit(replay_image, replay_image_rect) #顯示 reply 的圖示
        screen.blit(gameover_image, gameover_image_rect) #顯示 gameover 的圖示
        pygame.display.update()
        clock.tick(cfg.FPS)