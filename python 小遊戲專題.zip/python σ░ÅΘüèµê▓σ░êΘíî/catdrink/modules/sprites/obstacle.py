#508170129 蘇靖媛
#508170076 蔡名彥

#import 模組
import random
import pygame


#人物障礙物的設置
class People(pygame.sprite.Sprite):
    def __init__(self, imagepaths, position=(600, 290), sizes=[(90, 90), (90, 90)], **kwargs):
        pygame.sprite.Sprite.__init__(self)
        #導入圖片大人物和小人物的切割設定大小讀取
        self.images = []
        image = pygame.image.load(imagepaths[0])
        for i in range(3): #大人物
            self.images.append(pygame.transform.scale(image.subsurface((i*101, 0), (101, 101)), sizes[0]))
        image = pygame.image.load(imagepaths[1])
        for i in range(3): #小人物
            self.images.append(pygame.transform.scale(image.subsurface((i*68, 0), (68, 64)), sizes[1]))
        self.image = random.choice(self.images)
        self.rect = self.image.get_rect()
        self.rect.left, self.rect.bottom = position
        self.mask = pygame.mask.from_surface(self.image)
        #定義必要變數
        self.speed = -10

    #將人物畫到螢幕上
    def draw(self, screen):
        screen.blit(self.image, self.rect)

    #update 
    def update(self):
        self.rect = self.rect.move([self.speed, 0])
        if self.rect.right < 0:
            self.kill()

#魚缸的設置
class Fishbowl(pygame.sprite.Sprite):
    def __init__(self, imagepaths, position=(600, 290),**kwargs):
        pygame.sprite.Sprite.__init__(self)
         #導入圖片設置魚缸位置狀態
        self.images = []
        image = pygame.image.load(imagepaths)
        self.image = pygame.transform.scale(image  , (60,60)) #遊戲內大小
        self.rect = self.image.get_rect()
        self.rect.left, self.rect.bottom = position #遊戲內位置
        self.mask = pygame.mask.from_surface(self.image) 
        #定義必要變數
        self.speed = -10
        drink = False

    #魚缸畫到螢幕上
    def draw(self, screen):
        screen.blit(self.image, self.rect)

    #update
    def update(self):
        self.rect = self.rect.move([self.speed, 0])
        if self.rect.right < 0:
            self.kill()


