#508170129 蘇靖媛
#508170076 蔡名彥

#import 模組
import pygame


#貓咪設定
class Catt(pygame.sprite.Sprite):
    def __init__(self, imagepaths, position=(40, 290), size=[(80, 80), (80, 80)], **kwargs):
        pygame.sprite.Sprite.__init__(self)
        #導入貓咪的所有圖片
        self.images = []
        image = pygame.image.load(imagepaths)
        for i in range(8): #切割一個一個的貓咪圖片設置大小
            self.images.append(pygame.transform.scale(image.subsurface((i*32, 0), (32, 32)), size[0])) #取值設定圖片大小
        
        self.image_idx = 0
        self.image = self.images[self.image_idx]
        self.rect = self.image.get_rect()
        self.rect.left, self.rect.bottom = position
        self.mask = pygame.mask.from_surface(self.image)

        #定義必要變數
        self.init_position = position
        self.refresh_rate = 5
        self.refresh_counter = 0
        self.speed = 11.5
        self.gravity = 0.6
        self.is_jumping = False
        self.is_dead = False
        self.movement = [0, 0]

    #跳躍的動作設置
    def jump(self, sounds):
        if self.is_dead or self.is_jumping: #如果死亡或跳會撥放音效
            return
        sounds['jump'].play()
        self.is_jumping = True
        self.movement[1] = -1 * self.speed

    #死亡的設置
    def die(self, sounds):
        if self.is_dead:
            return
        sounds['die'].play()
        self.is_dead = True

    #將貓畫至螢幕
    def draw(self, screen):
        screen.blit(self.image, self.rect)

    #載入當下狀態的貓咪圖片
    def loadImage(self):
        self.image = self.images[self.image_idx]
        rect = self.image.get_rect()
        rect.left, rect.top = self.rect.left, self.rect.top
        self.rect = rect
        self.mask = pygame.mask.from_surface(self.image)

    #更新貓咪
    def update(self):
        if self.is_dead: #貓咪死亡時圖片的設定
            self.image_idx = 4
            self.loadImage()
            return
        if self.is_jumping: #貓咪跳躍時圖片的設定
            self.movement[1] += self.gravity
            self.image_idx = 0
            self.loadImage()
            self.rect = self.rect.move(self.movement)
            if self.rect.bottom >= self.init_position[1]:
                self.rect.bottom = self.init_position[1]
                self.is_jumping = False
        else:
            if self.refresh_counter % self.refresh_rate == 0: #貓咪的動態動作設定
                self.refresh_counter = 0
                if self.image_idx == 1:
                    self.image_idx = 2
                elif self.image_idx == 2:
                    self.image_idx = 3
                else:
                    self.image_idx = 1
                self.loadImage()
        self.refresh_counter += 1