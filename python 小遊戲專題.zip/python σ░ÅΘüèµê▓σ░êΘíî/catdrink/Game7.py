#508170129 蘇靖媛
#508170076 蔡名彥

#主題:貓咪偷喝水大作戰
#參考google瀏覽器小恐龍遊戲
#參考作者: Charles

#import所需模組cfg、sys、random、pygame、Fishbowl
import cfg
import sys
import random
import pygame
from modules import *
from modules.sprites.obstacle import Fishbowl


#主程式
def main(highest_score):

    # 遊戲初始化
    pygame.init()
    screen = pygame.display.set_mode(cfg.SCREENSIZE) #顯示螢幕 
    pygame.display.set_caption('貓咪偷喝水大作戰')  #顯示螢幕視窗的主題

    # 導入聲音元素
    sounds = {}  
    for key, value in cfg.AUDIO_PATHS.items():  #利用for迴圈導入聲音路徑下的資料
        sounds[key] = pygame.mixer.Sound(value)

    # 遊戲開始介面
    GameStartInterface(screen, sounds, cfg)
    # 定義遊戲必要元素跟變數
    score = 0
    score_board = Scoreboard(cfg.IMAGE_PATHS['numbers'], position=(540, 15), bg_color=cfg.BACKGROUND_COLOR)  #記分板的內容設計
    highest_score = highest_score #最高分
    highest_score_board = Scoreboard(cfg.IMAGE_PATHS['numbers'], position=(435, 15), bg_color=cfg.BACKGROUND_COLOR, is_highest=True) #最高分計分板的設計
    Catty = Catt(cfg.IMAGE_PATHS['cat']) #導入貓咪的圖片路徑
    ground = Ground(cfg.IMAGE_PATHS['ground'], position=(0, cfg.SCREENSIZE[1])) #地面的內容設計導入地圖圖片設置位置
    people_sprites_group = pygame.sprite.Group()
    Fishbowl_sprites_group = pygame.sprite.Group()
    add_people_timer = 0
    score_timer = 0

    # 遊戲主循環
    clock = pygame.time.Clock() #計算時間導入分數
    #遊戲結束以及開始的啟動方法
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT: #狀態符合離開則結束
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN: #狀態被指定案件按下而觸發
                if event.key == pygame.K_SPACE or event.key == pygame.K_UP: #空白鍵或上鍵觸發開始以及貓跳起時的叫聲
                    Catty.jump(sounds)
        
        # 隨機加入人物在遊戲中
        add_people_timer += 1
        if add_people_timer > random.randrange(50, 100): #隨機生成物件取適當間隔
            add_people_timer = 0
            random_value = random.randrange(0, 10) #隨機生成數字決定生成人物或魚缸
            if random_value >= 5 and random_value <= 7:  
              people_sprites_group.add(People(cfg.IMAGE_PATHS['people']))
            else :
              Fishbowl_sprites_group.add(Fishbowl(cfg.IMAGE_PATHS['fishbowl']))

        # 更新遊戲元素
        ground.update()
        Catty.update()
        people_sprites_group.update()
        Fishbowl_sprites_group.update()

         #遊戲分數基礎設置
        score_timer += 1
        if score_timer > (cfg.FPS//12):
            score_timer = 0
            score += 1
            score = min(score, 99999)
            if score > highest_score: #滿分就停止計分
                highest_score = score
            if score % 100 == 0: #滿百分音效
                sounds['point'].play()
            if score % 1000 == 0: #滿千分加速
                ground.speed -= 1
                for item in people_sprites_group:
                    item.speed -= 1
                for item in Fishbowl_sprites_group:
                    item.speed -=1

        # 碰撞檢測機制
        for item in people_sprites_group: #撞到人會觸發 gameover
            if pygame.sprite.collide_mask(Catty, item):
                Catty.die(sounds)
        for item in Fishbowl_sprites_group : #碰到魚缸則觸發加分
            if pygame.sprite.collide_mask(Catty, item):
                score = score +5
                

          
              
        # 將遊戲元素畫到螢幕上
        ground.draw(screen)
        score_board.set(score)
        highest_score_board.set(highest_score)
        score_board.draw(screen)
        highest_score_board.draw(screen)
        Catty.draw(screen)
        people_sprites_group.draw(screen)
        Fishbowl_sprites_group.draw(screen)

        # 更新螢幕
        pygame.display.update()
        clock.tick(cfg.FPS)

        # 判斷遊戲是否結束
        if Catty.is_dead: #貓死亡及結束
            break
    # 遊戲結束介面
    return GameEndInterface(screen, cfg), highest_score


#判斷跑的機制
if __name__ == '__main__':
    highest_score = 0
    while True:
        flag, highest_score = main(highest_score)
        if not flag: break