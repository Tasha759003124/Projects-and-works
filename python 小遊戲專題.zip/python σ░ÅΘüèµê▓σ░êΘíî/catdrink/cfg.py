#508170129 蘇靖媛
#508170076 蔡名彥

#配置文件
import os


#螢幕大小 600*300
SCREENSIZE = (600, 300)  

#FPS:60
FPS = 60

#音樂素材路徑設定
AUDIO_PATHS = {
    'die': os.path.join(os.getcwd(), 'resources/audios/die.wav'),
    'jump': os.path.join(os.getcwd(), 'resources/audios/jump.wav'),
    'point': os.path.join(os.getcwd(), 'resources/audios/point.wav')
}

#圖片素材路徑設定
IMAGE_PATHS = {
    'people': [
        os.path.join(os.getcwd(), 'resources/images/Pbig.png'),
        os.path.join(os.getcwd(), 'resources/images/Psmall.png')
    ],
    'fishbowl' :os.path.join(os.getcwd(),'resources/images/fishbowl.png'),
    'cat': os.path.join(os.getcwd(), 'resources/images/Cat.png'),
    
    'gameover': os.path.join(os.getcwd(), 'resources/images/gameover.png'),
    'ground': os.path.join(os.getcwd(), 'resources/images/background.png'),
    'numbers': os.path.join(os.getcwd(), 'resources/images/numbers.png'),
    'replay': os.path.join(os.getcwd(), 'resources/images/replay.png')
}

##背景顏色設定
BACKGROUND_COLOR = (235, 235, 235)
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)